Name: Colin Gidzinski
ID: 120663460
Email: gidz3460@mylaurier.ca
Assignment_ID: CP476A0
Homework statement: I claim that the enclosed submission is my individual work
 
Check list, self-evaulation/marking, marking scheme:
Note: fill self-evaluation for each of the following bracket under A1 marks and evalutions below. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2  like [2/2]. 

Q1 [5/5] 
Q2 [10/10]
Q3 [5/5]  Give a 5 if you did this. tell what you have done
- I have a vps running ubuntu with all the required software installed  
- Live site: www.cgidzinski.me
Total: [ 20/20/ ]

Note that the readme file is a check list for yourself, and it also helps the marker to mark your assignment.